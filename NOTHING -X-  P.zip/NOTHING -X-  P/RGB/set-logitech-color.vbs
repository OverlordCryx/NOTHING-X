Option Explicit

Dim shell, fso, scriptDir, exePath, redValue, greenValue, blueValue, command
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
exePath = scriptDir & "\RGB\G213Direct.exe"

If Not fso.FileExists(exePath) Then
    WScript.Echo "Brak pliku: " & exePath
    WScript.Quit 1
End If

redValue = "255"
greenValue = "69"
blueValue = "0"

If WScript.Arguments.Count >= 3 Then
    redValue = WScript.Arguments.Item(0)
    greenValue = WScript.Arguments.Item(1)
    blueValue = WScript.Arguments.Item(2)
End If

command = """" & exePath & """ " & redValue & " " & greenValue & " " & blueValue
shell.Run command, 0, True
Set shell = Nothing
WScript.Quit