If WScript.Arguments.length = 0 Then
    CreateObject("Shell.Application").ShellExecute "wscript.exe", """" & WScript.ScriptFullName & """ runas", "", "runas", 0
    WScript.Quit
End If

Set shell = CreateObject("WScript.Shell")

Sub RunHidden(cmd)
    shell.Run "cmd /c " & cmd, 0, True
End Sub

RunHidden "netsh int ip reset"
RunHidden "netsh interface ipv4 reset"
RunHidden "netsh interface ipv6 reset"
RunHidden "netsh interface tcp reset"
RunHidden "netsh winsock reset"

RunHidden "powershell -NoP -C ""foreach ($dev in Get-PnpDevice -Class Net -Status 'OK') { pnputil /remove-device $dev.InstanceId }"""

RunHidden "pnputil /scan-devices"

Set shell = Nothing
WScript.Quit