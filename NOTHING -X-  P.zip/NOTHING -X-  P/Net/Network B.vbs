If WScript.Arguments.length = 0 Then
    Set objShell = CreateObject("Shell.Application")
    objShell.ShellExecute "wscript.exe", """" & WScript.ScriptFullName & """ runas", "", "runas", 0
    WScript.Quit
End If

Set shell = CreateObject("WScript.Shell")

Sub RunCmd(cmd)
    shell.Run "cmd /c " & cmd, 0, True
End Sub


RunCmd "netsh interface ipv4 set interface ""Ethernet 2"" metric=3"
RunCmd "netsh interface ipv4 set subinterface ""Ethernet 2"" mtu=1472 store=persistent"
RunCmd "netsh interface ipv6 set interface ""Ethernet 2"" mtu=1472"


RunCmd "netsh interface tcp set global autotuninglevel=experimental"
RunCmd "netsh interface tcp set global rss=enabled"
RunCmd "netsh interface tcp set global chimney=enabled"
RunCmd "netsh interface tcp set global netdma=enabled"
RunCmd "netsh interface tcp set global fastopen=enabled"
RunCmd "netsh interface tcp set global receivecoalescing=enabled"
RunCmd "netsh interface tcp set global hystart=enabled"
RunCmd "netsh interface tcp set global proportionalreducerate=enabled"
RunCmd "netsh interface tcp set global nonsackrttresiliency=enabled"
RunCmd "netsh interface tcp set global timestamps=enabled"
RunCmd "netsh interface tcp set global ecncapability=enabled"
RunCmd "netsh interface tcp set global pacingprofile=off"
RunCmd "netsh interface tcp set heuristics disabled"

RunCmd "netsh interface ipv4 set global icmpredirects=disabled"
RunCmd "netsh interface ipv4 set global multicastforwarding=disabled"

RunCmd "netsh interface ip set dns name=""Ethernet 2"" static 1.1.1.1"
RunCmd "netsh interface ip add dns name=""Ethernet 2"" 1.0.0.1 index=2"

RunCmd "netsh int tcp set global dca=enabled"

RunCmd "powercfg -setactive SCHEME_MIN"

RunCmd "ipconfig /flushdns"
RunCmd "netsh int ip reset"
Set shell = Nothing
WScript.Quit