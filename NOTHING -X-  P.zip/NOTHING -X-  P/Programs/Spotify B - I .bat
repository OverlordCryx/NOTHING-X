@echo off
mode con: cols=100 lines=55
color 4
echo ===============================
echo      Spotify AD Block
echo ===============================
:run_block
echo -------------------------
echo   Spotify AD Block Run
echo -------------------------
set /p dummy=Press ENTER to continue...

%SYSTEMROOT%\System32\WindowsPowerShell\v1.0\powershell.exe -Command "&{[Net.ServicePointManager]::SecurityProtocol = 3072}; """"& { $(Invoke-WebRequest -UseBasicParsing 'https://spotx-official.github.io/run.ps1')} -new_theme """" | Invoke-Expression"

echo.
echo -------------------------
echo          DONE
echo -------------------------
set /p dummy=Press ENTER to exit...
exit /b

