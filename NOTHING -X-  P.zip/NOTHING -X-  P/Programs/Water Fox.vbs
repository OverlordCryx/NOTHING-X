Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

scriptDir = objFSO.GetParentFolderName(WScript.ScriptFullName)

url = "https://cdn.waterfox.com/waterfox/releases/6.6.11/WINNT_x86_64/Waterfox%20Setup%206.6.11.exe"
savePath = scriptDir & "\Waterfox Setup 6.6.11.exe"

psCommand = "powershell -ExecutionPolicy Bypass -WindowStyle Hidden -Command ""Invoke-WebRequest -Uri '" & url & "' -OutFile '" & savePath & "'"""

objShell.Run psCommand, 0, False