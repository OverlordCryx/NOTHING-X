Set objArgs = WScript.Arguments
Set objShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

If objArgs.Count = 0 Then WScript.Quit

text = ""

For i = 0 To objArgs.Count - 1
    text = text & objArgs(i) & vbCrLf
Next

tmp = objShell.ExpandEnvironmentStrings("%TEMP%") & "\clip_tmp.txt"

Set file = fso.CreateTextFile(tmp, True)
file.Write text
file.Close

objShell.Run "cmd /c type """ & tmp & """ | clip", 0, True

If fso.FileExists(tmp) Then
    fso.DeleteFile tmp, True
End If