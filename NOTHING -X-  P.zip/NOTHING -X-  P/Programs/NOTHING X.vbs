Set shell = CreateObject("WScript.Shell")
consoleKey = "HKCU\Console\NOTHING X Codex\"

WriteString shell, consoleKey & "FaceName", "SimSun-ExtB"
WriteDword shell, consoleKey & "FontFamily", 54
WriteDword shell, consoleKey & "FontWeight", 400
WriteDword shell, consoleKey & "FontSize", 1114121
WriteDword shell, consoleKey & "ScreenBufferSize", 589889601
WriteDword shell, consoleKey & "WindowSize", 3932225
WriteDword shell, consoleKey & "QuickEdit", 1
WriteDword shell, consoleKey & "InsertMode", 1
WriteDword shell, consoleKey & "HistoryBufferSize", 1
WriteDword shell, consoleKey & "NumberOfHistoryBuffers", 1
WriteDword shell, consoleKey & "HistoryNoDup", 0
WriteDword shell, consoleKey & "LineWrap", 1
WriteDword shell, consoleKey & "LineSelection", 1
WriteDword shell, consoleKey & "FilterOnPaste", 1
WriteDword shell, consoleKey & "ExtendedEditKey", 1
WriteDword shell, consoleKey & "CtrlKeyShortcutsDisabled", 0
WriteDword shell, consoleKey & "ForceV2", 1
WriteDword shell, consoleKey & "CursorSize", 25
WriteDword shell, consoleKey & "WindowAlpha", 240
WriteDword shell, consoleKey & "ScreenColors", 6
WriteDword shell, consoleKey & "PopupColors", 245
WriteDword shell, consoleKey & "ColorTable00", 0
WriteDword shell, consoleKey & "ColorTable06", 48383
WriteDword shell, consoleKey & "ColorTable07", 15724527

shell.Run "cmd.exe /k ""title NOTHING X Codex && cd /d """"C:\Users\Administrator\Videos\NOTHING X"""" && codex -a never -s danger-full-access""", 1, False

Sub WriteDword(sh, path, value)
    sh.RegWrite path, value, "REG_DWORD"
End Sub

Sub WriteString(sh, path, value)
    sh.RegWrite path, value, "REG_SZ"
End Sub
